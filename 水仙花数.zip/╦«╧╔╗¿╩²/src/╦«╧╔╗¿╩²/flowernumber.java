package ˮ�ɻ���;
public class flowernumber {
	    public static void main(String[]args){
	    int shuixianshu ;
	    int panduan;
	    System.out.print("ˮ�����У�");
	    for (int i = 1;i<10 ;i++ ){
	        for (int a = 0;a<10 ;a++ ){
	            for (int b = 0;b<10 ;b++ ){
	                shuixianshu = i*100+a*10+b;
	                panduan = i*i*i+a*a*a+b*b*b;
	                if (shuixianshu == panduan){
	                    System.out.print(shuixianshu+" ");
	                }
	            }
	        }
	    }
	}
}