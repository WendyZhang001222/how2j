package �ƽ�ָ�;
public class goldencut {
	    public static void main(String[]args){
	    double n = 0;
	    double m = 1;
	    double c = 0;
	    double d = 0;
	    for (double a = 1;a <= 20 ;a++ ){
	        for (double b = (a+1);b <= 20 ;b++ ){
	            n = a/b;
	            if (((a%2) == 0) & ((b%2) == 0)){
	                continue;
	                }
	                if (n > 0.618){
	                    if ((n-0.618) < m){
	                        m = (n-0.618);
	                        c = a;
	                        d = b;
	                        }
	                    }else{
	                    if ((0.618-n)<m){
	                        m = (0.618-n);
	                        c = a;
	                        d = b;
	                    }
	                 }
	            }
	        }
	    System.out.println("��ƽ�ָ��㣨0.618�����������������ǣ�" + c +"/" + d+ "=" + (c/d) );
	 
	    }
	
}
