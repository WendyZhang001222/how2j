package ������;

public class millionaire {
	    public static void main(String[] args) {
	        int fundPerMonth = 1000;
	        int fundPerYear = fundPerMonth *12;
	        float rate = 0.20f;
	        //F = p* ( (1+r)^n );
	        int sum = 0;
	        int target = 1000*1000;
	        for (int j = 1; j < 100; j++) {
	            int year = j;
	            float compoundInterestRate = 1;
	            for (int i = 0; i < year; i++) {
	                compoundInterestRate = compoundInterestRate * (1+rate);
	            }
	            int compoundInterest = (int) (fundPerYear * compoundInterestRate);         
	 
	            sum +=compoundInterest;
	            System.out.println("����" + year + " �꣬ ������ " + sum);
	            if(sum>=target){
	                System.out.println("һ����Ҫ" + year + "�꣬�ۼ����볬��" + target );
	                break;
	            }
	        }
	 
	    }
	
}
