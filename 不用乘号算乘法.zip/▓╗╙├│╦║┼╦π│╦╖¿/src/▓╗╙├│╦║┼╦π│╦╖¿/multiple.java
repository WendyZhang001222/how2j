package ���ó˺���˷�;

public class multiple {
	public static void main(String[] args) { 
		int i = 2;
	    int j = 2*16; //ʹ�ó˷�
	    System.out.println("j=2*16:\t"+j);
	    int k = 2<<4;
	    System.out.println("k=2<<4:\t"+k);
	}
}

