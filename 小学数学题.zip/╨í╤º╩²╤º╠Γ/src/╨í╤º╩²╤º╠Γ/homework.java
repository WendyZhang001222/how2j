package Сѧ��ѧ��;
public class homework {
	public static void main(String[] args) {
	for (int i = -100; i < 100; i++)
	{
	    int a = 8-i;
	    int b = 14-i;
	    int c = 10-a;
	    if(b == c+6) System.out.format("%d + %d = 8\n"
	            + "+   +\n"
	            + "%d - %d = 6\n"
	            + "||   ||\n"
	            + "14   10", i, a, b, c);
		}
	}
}